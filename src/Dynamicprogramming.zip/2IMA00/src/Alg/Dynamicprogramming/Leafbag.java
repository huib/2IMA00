/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alg.Dynamicprogramming;

import java.util.ArrayList;
import Alg.TreeDecomposition.Bag;

/**
 *
 * @author Victor-Xi
 */
public class Leafbag {

    public static void processleafbag(Bag t) {
        System.out.println("Leaf bag is processing"+t.vert);
//        ArrayList<Integer> s1 = (ArrayList<Integer>) t.vert.clone();
//        ArrayList<Integer> s2 = (ArrayList<Integer>) t.vert.clone();
        ArrayList s = new ArrayList();
//        for (int i = 0; i <= s1.size(); i++) {
//            int a[][] = new int[s1.get(i)][s2.get(i)];
//            s.add(a);
//        }
        ArrayList<Recurrence> v = new ArrayList();
        Integer k = Dynamicprogramming.vertsize;
        /*List<Integer> p=new ArrayList<Integer>();*/
//        k = 1;
        for (int a = 0; a <= k; a++) {
            for (int b = 0; b <= k; b++) {
                for (int c = 0; c <= k; c++) {
                    for (int w = 0; w <= 8 * k*k; w++) {
//                        mappings m = new mappings(s1, s2);
                        if (a == 0 && b == 0 && c == 0 && w==0) {
                            v.add(new Recurrence(a, b, c, w, 1));/*将每个计算出来的类存进V列表里并返回*/
//                            System.out.println("Yay!");
                        }
                        else {
//                            Recurrence r = new Recurrence(a,b,c,w,0);
                            v.add(new Recurrence(a, b, c, w, 0));/*将每个计算出来的类存进V列表里并返回*/
//                            System.out.println("Nay :(");
                        }
                    }
                }
            }
        }
//        for(Recurrence z: v){
//            System.out.println(z.A + " " + z.B);
//        }
        ArrayList<Subentries> f =new ArrayList();
        f.add(new Subentries(s,v));
//        System.out.println(k+"size"+8*k*k*k*k*k);
//        System.out.println(f.get(0).key.size());
        /*int k=(int) Math.pow(3,s1.size());*/
//        String name = "bag" + t.num;
        t.entry=new ArrayList(f);
//        Dynamicprogramming.f=new ArrayList(f);
        t.process = true;
        System.out.println("Leaf bag is handled"+t.vert);
//        System.out.println(t.entry.get(0).key.size());
        Dynamicprogramming.Waitinglist.add(t.parent);
    }
}
