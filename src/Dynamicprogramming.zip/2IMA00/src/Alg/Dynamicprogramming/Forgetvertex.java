/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alg.Dynamicprogramming;

import Alg.TreeDecomposition.Bag;
import java.util.ArrayList;
import java.util.Collection;

/**
 *
 * @author Victor-Xi
 */
public class Forgetvertex {

    public static void forgetvertexprocess(Bag t) {
        ArrayList<Bag> y = t.children;
        Collection child = (ArrayList<Integer>) y.get(0).vert.clone();
        Collection parent = (ArrayList<Integer>) t.vert.clone();
        ArrayList<Integer> s2 = new ArrayList<Integer>(child);
        ArrayList<Integer> s1 = new ArrayList<Integer>(parent);
//        System.out.println(s1);
//        System.out.println(s2);
        s2.removeAll(s1);
//        System.out.println("s1" + s1+ "s2"+s2);
        ArrayList<Subentries> in = new ArrayList();
        ArrayList<Subentries> f = new ArrayList();
//        String childname = "bag" + y.get(0).num;
        Integer k = Dynamicprogramming.vertsize;
        Integer mweight = 0;
        if (y.get(0).process) {
//            System.out.print(y.get(0).entry.size());
            System.out.println("Forget vertex bag is processing" + t.vert + "child" + y.get(0).vert);
            Integer vert = s2.get(0);/*forget vertice*/
            for (int i = 0; i < Dynamicprogramming.Weighttable.size(); i++) {
                if (Dynamicprogramming.Weighttable.get(i).vert == vert)/*find the Forest weight of v*/ {
                    mweight = Dynamicprogramming.Weighttable.get(i).Mweight;
                    break;
                }
            }
//            for (int i = 0; i < Dynamicprogramming.Table.size(); i++) {/*find all entries of its child*/
//                if (Dynamicprogramming.Table.get(i).nodename == childname) {
            in = new ArrayList(y.get(0).entry);
//            for(int i=0;i<in.size();i++){System.out.print("Insize="+in.size()+in.get(i).key.size());}
//                    break;
//                }
//            }
            ArrayList<Subentries> temp = new ArrayList(y.get(0).entry);
            ArrayList<Integer> handled = new ArrayList();
            ArrayList<Integer> handledin = new ArrayList();
//            for(int i=1;i<temp.get(0).s.size();i++){
//            int a1[] = (int[]) temp.get(2).s.get(i);
//            System.out.println(a1[0]+""+a1[1]);}
            for (int i = 0; i < temp.size(); i++) {/*v in X1*/
//                ArrayList a = temp.get(i).s;
//                ArrayList<recurrence> v = new ArrayList();
//                Integer color = 0;
//                Integer index=0;
                for (int z = 0; z < temp.get(i).s.size(); z++) {
                    int a2[] = (int[]) temp.get(i).s.get(z);
                    if (a2[0] == vert) {
                        temp.get(i).s.remove(z);
//                    index=z;
//                    color = a2[1];
                    }
                }
            }
//            for(int i=0;i<temp.size();i++){System.out.print("tempsize="+temp.size()+temp.get(i).key.size());}
            for (int l = 0; l < temp.size(); l++) {
                for (int j = l + 1; j < temp.size(); j++) {
                   
//                    if (!handled.isEmpty()) {
                        if (!handled.contains(l) && !handled.contains(j) && Comparing.comparing(temp.get(l).s, temp.get(j).s)) {
                            for (int p = 0; p < temp.get(l).key.size(); p++) {
                                temp.get(l).key.get(p).N = temp.get(l).key.get(p).N + temp.get(j).key.get(p).N;
                            }
                            handled.add(j);
                        }
//                    }
//                    else{
//                        for (int p = 0; p < temp.get(l).key.size(); p++) {
////                             System.out.println(temp.get(1).key);
//                                temp.get(l).key.get(p).N = temp.get(l).key.get(p).N + temp.get(j).key.get(p).N;
//                            }
//                            handled.add(j);
//                    }
                }
            }
            
            int move=0;
            for (int b = 0; b < handled.size(); b++) {
                int h = (int)handled.get(b)-move;
                temp.remove(h);
                move++;

            }
//            System.out.print(temp.size());
//            System.out.println("temp"+temp.size()+"in"+in.size());
            
            for (int c = 0; c < in.size(); c++) {/*v in X1*/
//                ArrayList a = temp.get(i).s;
//                ArrayList<recurrence> v = new ArrayList();
//                Integer color = 0;
//                Integer index=0;
//                System.out.print("s.size"+in.size());
                for (int z = 0; z < in.get(c).s.size(); z++) {
                    int a2[] = (int[]) in.get(c).s.get(z);
//                    System.out.print("z"+z);
                    if (a2[0] == vert && a2[1] == 1) {
                        in.get(c).s.remove(z);
                        break;
//                    index=z;
//                    color = a2[1];
                    } else if(z==(in.get(c).s.size()-1)){
                        handledin.add(c);
                    }
                }
            }
            int move2=0;
            for (int b = 0; b < handled.size(); b++) {
                int h = (int)handled.get(b)-move2;
                in.remove(h);
                move2++;

            }
//            System.out.print(in.size());
            for (int l = 0; l < temp.size(); l++) {
                for (int j = 0; j < in.size(); j++) {
                    if (Comparing.comparing(temp.get(l).s, in.get(j).s)) {
                        for (int b = 0; b < temp.get(l).key.size(); b++) {
//                            for (int p = 0; p < in.get(j).key.size(); p++) {
                                
//                                Recurrence r1 = temp.get(l).key.get(b);
                                Integer p=b-8*k*k-mweight;
//                                Recurrence r2 = in.get(j).key.get(p);
                                if (p>=0) {
                                    temp.get(l).key.get(b).N = temp.get(l).key.get(b).N + in.get(j).key.get(p).N;
                                }
//                            }
                        }
                    }
                }
            }
            
            //            for (int p = 0; p <= k; p++) {
            //                for (int b = 0; b <= k; b++) {
            //                    for (int c = 0; c <= k; c++) {
            //                        for (int w = 0; w <= 4 * k; w++) {
            //                            Integer r = 0;
            //                            for (int j = 0; j < in.get(i).key.size(); j++) {
            //
            //                                recurrence h = in.get(i).key.get(j);
            //                                if (h.A == p - 1 && h.B == b && h.C == c && h.W == w - mweight) {
            //                                    v.add(new recurrence(p, b, c, w, h.N));/*将每个计算出来的类存进V列表里并返回*/
            //                                } else {
            //                                    v.add(new recurrence(p, b, c, w, 0));/*将每个计算出来的类存进V列表里并返回*/
            //                                }
            //                            }
            //                            v.add(new recurrence(p, b, c, w, r));
            //                        }
            //                    }
            //                }
            //            }
            //            a.remove(index);
            //            f.add(new Subentries(a, v));
            //            v.clear();
            /*int k=(int) Math.pow(3,s1.size());
      for(int i=0;i<k;i++){
      }/*写一个循环,给bx的每个element延伸出一个值(0,1,2),遍历所有可能性,并赋予R.S*/
//            String name = "bag" + t.num;
//            Dynamicprogramming.Table.add(new entries(name, temp));
            t.entry = new ArrayList(temp);
            t.children.get(0).entry=null;
            temp=null;
            in=null;
//            Dynamicprogramming.f=new ArrayList(temp);
            t.process = true;
            System.out.print(t.entry.size());
//            t.children.get(0).entry.clear();
            if (t.parent!=null){
            Dynamicprogramming.Waitinglist.add(t.parent);}
//            System.out.print(t.entry.size());
            System.out.println("Forget vertex bag is handled" + t.vert + "child" + y.get(0).vert);
        } else if (!y.get(0).process) {
            Dynamicprogramming.Waitinglist.add(y.get(0));
            return;
        }
    }

}
