/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alg.Dynamicprogramming;

import java.util.ArrayList;

/**
 *
 * @author Victor-Xi
 */
public class Comparing {

    public static Boolean comparing(ArrayList p, ArrayList q) {
        Boolean f = false;
        if (p.size() == 0 && q.size()==0) {
                f = true;
            }
        else{
        for (int z = 0; z < p.size(); z++) {
            int a1[] = (int[]) p.get(z);
            int a2[] = (int[]) q.get(z);
//            System.out.println("p" + a1[0]+a1[1] + "q" + a2[0]+a2[1]);
            if (a1[1] != a2[1]) {
                f= false;
                break;
            }
            else if(a1[1]==a2[1]&&z==p.size()-1)
            {
                f=true;
            }
        }}
//        System.out.println("result"+f);
        return f;

    }
}
