/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alg.Dynamicprogramming;

import Alg.TreeDecomposition.Bag;
import java.util.ArrayList;
import java.util.Collection;

/**
 *
 * @author Victor-Xi
 */
public class Introduceedge {

    public static void introduceedgeprocess(Bag t) {
        ArrayList<Bag> y = new ArrayList(t.children);
        ArrayList<Subentries> in = new ArrayList();
        ArrayList<Subentries> f = new ArrayList();
//        String childname = "bag" + y.get(0).num;
        Integer k = Dynamicprogramming.vertsize;
//        Integer Fweight = 0;
        if (y.get(0).process) {
            System.out.println("Add edge bag is processing" + t.vert + "child" + y.get(0).vert);
//            System.out.println(t.children.get(0).edge);
            Integer vert = t.edge.a;/*introduce edge vertice*/
            Integer uvert = t.edge.b;/*introduce edge vertice*/
//            for (int i = 0; i < Dynamicprogramming.Weighttable.size(); i++) {
//                if (Dynamicprogramming.Weighttable.get(i).vert == vert)/*find the Forest weight of v*/ {
//                    Fweight = Dynamicprogramming.Weighttable.get(i).Fweight;
//                    break;
//                }
//            }
//            for (int i = 0; i < Dynamicprogramming.Table.size(); i++) {/*find all entries of its child*/
//                if (Dynamicprogramming.Table.get(i).nodename == childname) {
            in = y.get(0).entry;
//                    break;
//                }
//            }

            for (int i = 0; i < in.size(); i++) {/*v in X1*/
                ArrayList a = new ArrayList(in.get(i).s);
                ArrayList<Recurrence> v = new ArrayList();
                Integer left = 0;
                Integer right = 0;
                for (int z = 0; z < a.size(); z++) {
                    int a2[] = (int[]) a.get(z);
                    if (a2[0] == vert) {
                        left = a2[1];
                    } else if (a2[0] == uvert) {
                        right = a2[1];
                    }
                }
                if (left == 0 || right == 0 || left == right) {
                    if (left == right && left != 0) {
                        for (int p = 0; p <= k; p++) {
                            for (int b = 0; b <= k; b++) {
                                for (int c = 0; c <= k; c++) {
                                    for (int w = 0; w <= 8 * k * k; w++) {
                                        if (b == 0) {
                                            v.add(new Recurrence(p, b, c, w, 0));
                                        }
                                        else{
                                            int j=p*k*k*8*k*k+(b-1)*k*8*k*k+c*8*k*k+w;
                                            v.add(in.get(i).key.get(j));
                                        }
//                                        for (int j = 0; j < in.get(i).key.size(); j++) {
//                                            Recurrence h = in.get(i).key.get(j);
//                                            if (h.B != k) {
//                                                v.add(new Recurrence(h.A, h.B + 1, h.C, h.W, h.N));/*将每个计算出来的类存进V列表里并返回*/
//                                            } else {
//                                                continue;
//                                            }

                                        }
                                    }
                                    
//                        v.clear();
                                }
                            }
                        f.add(new Subentries(a, v));
                    } else {
                        f.add(in.get(i));
                    }
                } else {
//                    for (int p = 0; p <= k; p++) {
//                        for (int b = 0; b <= k; b++) {
//                            for (int c = 0; c <= k; c++) {
//                                for (int w = 0; w <= 8 * k * k; w++) {
//                                    v.add(new Recurrence(p, b, c, w, 0));/*将每个计算出来的类存进V列表里并返回*/
//                                }
//                            }
//                        }
//                    }
                    f.add(new Subentries(a, Dynamicprogramming.rec));
//                    v.clear();
                }
            }
            /*int k=(int) Math.pow(3,s1.size());
      for(int i=0;i<k;i++){
      }/*写一个循环,给bx的每个element延伸出一个值(0,1,2),遍历所有可能性,并赋予R.S*/
//            String name = "bag" + t.num;
            t.children.get(0).entry=null;
            t.entry = new ArrayList(f);
            f=null;
            in=null;
//                Dynamicprogramming.f=new ArrayList(f);
//            Dynamicprogramming.Table.add(new entries(name, f));
            t.process = true;
//            t.children.get(0).entry.clear();
            Dynamicprogramming.Waitinglist.add(t.parent);
            System.out.println("Add vertex bag is handled" + t.vert);
        } else if (!y.get(0).process) {
            Dynamicprogramming.Waitinglist.add(y.get(0));
//            Dynamicprogramming.Waitinglist.add(t);
            return;
        }
    }

}
