/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alg.Dynamicprogramming;

import java.util.ArrayList;
import Alg.TreeDecomposition.Bag;

/**
 *
 * @author Victor-Xi
 */
public class Recurrence {

    public Integer A;
    public Integer B;
    public Integer C;
    public Integer W;
    public Integer N;
    /*public static mappings S;*/

    public Recurrence(int a, int b, int c, int w, int n) {
        A = a;
        B = b;
        C = c;
        W = w;
        /*S = s;*/
        N = n;
    }
}
