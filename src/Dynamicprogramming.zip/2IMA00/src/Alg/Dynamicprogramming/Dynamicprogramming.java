/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alg.Dynamicprogramming;

import Alg.TreeDecomposition.Bag;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.Multigraph;

/**
 *
 * @author Victor-Xi
 */
public class Dynamicprogramming {

    /*public static Map<String,ArrayList> map=new HashMap<>();*/
    public static ArrayList<Entries> Table;
    public static ArrayList<Weight> Weighttable;
//    public static ArrayList<Integer> Marker;
    public static Queue<Bag> Waitinglist;
    public static Integer vertsize;
    public static ArrayList<Recurrence> rec;

    public static void makec() {
        rec=new ArrayList();
        for (int p = 0; p <= vertsize; p++) {
            for (int b = 0; b <= vertsize; b++) {
                for (int c = 0; c <= vertsize; c++) {
                    for (int w = 0; w <= 8 * vertsize * vertsize; w++) {
                        rec.add(new Recurrence(p, b, c, w, 0));/*将每个计算出来的类存进V列表里并返回*/
                    }
                }
            }
        }
    }

    public static void calweight(Multigraph<Integer, DefaultEdge> graph) {
        Random rand = new Random();
        ArrayList<Weight> w = new ArrayList();
//        vertsize=k;
        Iterator it = graph.vertexSet().iterator();
        ArrayList<Integer> h = new ArrayList();
        while (it.hasNext()) {
            int p = (int) it.next();
            h.add(p);
        }
        vertsize = h.size();
        Integer k = vertsize;
        for (int i = 0; i < h.size(); i++) {
            w.add(new Weight(h.get(i), rand.nextInt(4 * k) + 1, rand.nextInt(4 * k) + 1));
        }
        Weighttable = w;
    }

    /**
     *
     * @param b
     */
    public static Queue waitinglist(Bag b) {
//        for (int i = 0; i < b.num; i++) {
//            if (b.isLeaf()) {
        Queue<Bag> w = new LinkedList<Bag>();
        w.add(b);
        Waitinglist = w;
        return Waitinglist;
//            }
//        }
    }

    public static void process(Queue w) {
        while (Waitinglist.size() > 0) {
//            System.out.print(Waitinglist.peek().isLeaf());
            Bag p = Waitinglist.poll();
            if (p.isLeaf()) {
//                System.out.print(p.parent);
                Leafbag.processleafbag(p);
            } else if (p.isForget()) {
//                System.out.println(p.isForget());
                Forgetvertex.forgetvertexprocess(p);
            } else if (p.isAdd()) {
//                System.out.println(p.isAdd());
                Introducevertex.introduceprocess(p);
            } else if (p.isAddedge()) {
                Introduceedge.introduceedgeprocess(p);
            }

//            System.out.println(Waitinglist.size());
        }
    }

}
