/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alg.Dynamicprogramming;

import Alg.InputReader;
import Alg.TreeDecomposition.Bag;
import Alg.TreeDecomposition.TreeDecomposition;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.Multigraph;

/**
 *
 * @author Victor-Xi
 */
public class Main {

    public static void main(String[] args) {

        // Read from command line
        // Scanner scanner = new Scanner(System.in);
        // Read from file
//        Scanner scanner = null;
//        try {
//            scanner = new Scanner(new File("/Users/Victor-Xi/Documents/Q4/algorithm seminar/2IMA00-master/instances/099_c.graph"));
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//            return;
//        }
//
//        Multigraph graph = InputReader.readGraph(scanner);
        Multigraph<Integer, DefaultEdge> graph = new Multigraph<>(DefaultEdge.class);
        graph.removeAllEdges(graph.edgeSet());
        graph.removeAllVertices(graph.vertexSet());
        graph.addVertex(1);
        graph.addVertex(2);
        graph.addVertex(3);
        graph.addVertex(4);
        graph.addVertex(5);
        graph.addVertex(6);
        graph.addVertex(7);
//        graph.addVertex(8);
//        graph.addVertex(9);
//        graph.addVertex(10);
//        graph.addVertex(11);
//        graph.addVertex(12);
//        graph.addVertex(13);
//        graph.addVertex(14);
//        graph.addVertex(15);
        graph.addEdge(1, 2);
        graph.addEdge(2, 3);
        graph.addEdge(3, 1);
        graph.addEdge(3, 4);
        graph.addEdge(4, 5);
        graph.addEdge(5, 1);
        graph.addEdge(6, 2);
        graph.addEdge(6, 7);
//        graph.addEdge(6, 8);
//        graph.addEdge(8, 9);
//        graph.addEdge(9, 10);
//        graph.addEdge(11, 12);
//        graph.addEdge(12, 14);
//        graph.addEdge(13, 14);
//        graph.addEdge(13, 15);
        
        
//        graph.addEdge(4, 5);
        
        
//       System.out.println(graph.edgeSet());
        
//        Iterator it = graph.vertexSet().iterator();
//        ArrayList<Integer> h=new ArrayList();
//        while (it.hasNext()){
//        int p=(int) it.next();
//        h.add(p);
//        }

//        System.out.println(graph.vertexSet());
//        System.out.println(h);
        Bag rootbag = Alg.TreeDecomposition.TreeDecomposition.makePathDecomposition(graph);
        Bag nice = Alg.TreeDecomposition.TreeDecomposition.makeNice(rootbag);
        Bag handle = Alg.TreeDecomposition.TreeDecomposition.addEdges(nice, graph);
//        Alg.TreeDecomposition.TreeDecomposition.print(handle);
//        System.out.println(handle.vert);
        Alg.Dynamicprogramming.Dynamicprogramming.calweight(graph);
        Queue w = Alg.Dynamicprogramming.Dynamicprogramming.waitinglist(handle);
        Dynamicprogramming.makec();
        Alg.Dynamicprogramming.Dynamicprogramming.process(w);
////        System.out.print(nice.entry.size());
        outerloop:
        for (int i = 0; i < handle.entry.size(); i++) {
            for (int j = 0; j < handle.entry.get(i).key.size(); j++) {
                if (handle.entry.get(i).key.get(j).N % 2 == 1) {
                    System.out.println("Yes,there is such a solution");
                    break outerloop;
                }
            }
            if (i == handle.entry.size() - 1) {
                System.out.println("No,there is not such solutions");
            }
        }

    }

}
