/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alg.Dynamicprogramming;

import java.util.ArrayList;

/**
 *
 * @author Victor-Xi
 */
public class Subentries {
    public ArrayList s;
    public ArrayList<Recurrence> key;
    public Subentries(ArrayList a,ArrayList y) {
    s=a;    
    key=y;
    }
}