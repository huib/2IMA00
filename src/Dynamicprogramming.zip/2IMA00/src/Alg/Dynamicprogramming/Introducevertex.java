/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Alg.Dynamicprogramming;

import Alg.TreeDecomposition.Bag;
import java.util.ArrayList;
import java.util.Collection;

/**
 *
 * @author Victor-Xi
 */
public class Introducevertex {

    public static void introduceprocess(Bag t) {
        ArrayList<Bag> y = new ArrayList(t.children);
        Collection child = (ArrayList<Integer>) y.get(0).vert.clone();
        Collection parent = (ArrayList<Integer>) t.vert.clone();
        ArrayList<Integer> s2 = new ArrayList<Integer>(child);
        ArrayList<Integer> s1 = new ArrayList<Integer>(parent);
        s1.removeAll(s2);
        ArrayList<Subentries> in = new ArrayList();
        ArrayList<Subentries> f = new ArrayList();
//        String childname = "bag" + y.get(0).num;
        Integer k = Dynamicprogramming.vertsize;
        Integer Fweight = 0;
        if (y.get(0).process) {
            System.out.println("Add vertex bag is processing" + t.vert + "child" + y.get(0).vert);
            Integer vert = s1.get(0);/*introduce vertice*/
            for (int i = 0; i < Dynamicprogramming.Weighttable.size(); i++) {
                if (Dynamicprogramming.Weighttable.get(i).vert == vert)/*find the Forest weight of v*/ {
                    Fweight = Dynamicprogramming.Weighttable.get(i).Fweight;
                    break;
                }
            }
//            System.out.println("weight founded");
//            for (int i = 0; i < Dynamicprogramming.Table.size(); i++) {/*find all entries of its child*/
//                if (Dynamicprogramming.Table.get(i).nodename == childname) {
            in = y.get(0).entry;

//                    break;
//                }
//            }
            for (int i = 0; i < in.size(); i++) {/*v not in X*/
                ArrayList a1 = new ArrayList(in.get(i).s);
//                System.out.println(in.get(i).key);
//                System.out.println(y.get(0).entry.get(0).s);               
                int a[] = new int[2];
                a[0] = vert;
                a[1] = 0;
                a1.add(a);
                f.add(new Subentries(a1, in.get(i).key));
//                System.out.println(f.get(0).s);
//                a1.clear();
            }
//            System.out.println("Not in X done");
            for (int i = 0; i < in.size(); i++) {/*v in X*/
//              System.out.println("first loop" + in.size());
                ArrayList a1 = new ArrayList(in.get(i).s);
                ArrayList a2 = new ArrayList(in.get(i).s);
                int a[] = new int[2];
                int m[] = new int[2];
                a[0] = vert;
                a[1] = 1;
//                System.out.println(a[0]+""+a[1]);
                m[0] = vert;
                m[1] = 2;
//                System.out.println(m[0]+""+m[1]);
                a1.add(a);
                a2.add(m);
                
        
                
//                System.out.println(a1.get(0));
                ArrayList<Recurrence> v = new ArrayList();
                for (int p = 0; p <= k; p++) {
                        for (int b = 0; b <= k; b++) {
                            for (int c = 0; c <= k; c++) {
                                for (int w = 0; w <= 8 *k*k; w++) {
                                if ((p - 1) >= 0 && (w - Fweight) >= 0) {
//                                    for (int j = 0; j < in.get(i).key.size(); j++) {
//                                        if (j % 10000 == 0) {
////                                            System.out.println("p:" + p + "w:" + w + "b" + b + "c" + c);
//                                        }
                                        int j=(p-1)*k*k*8*k*k+b*k*8*k*k+c*8*k*k+(w-Fweight);
//                                        Recurrence h = in.get(i).key.get(j);
////                                        if (h.A < p - 1 || h.B < b || h.C < c || h.W < (w - Fweight)) {
////                                            in.get(i).key.remove(j);
                                    
////                                        } 
                                            in.get(i).key.get(j).A=in.get(i).key.get(j).A+1;
                                            in.get(i).key.get(j).W=in.get(i).key.get(j).W+Fweight;
//else 
//                                            if (h.A == p - 1 && h.B == b && h.C == c && h.W == w - Fweight) {
                                            v.add(in.get(i).key.get(j));
//                                            in.get(i).key.remove(j);
//                                            break;/*将每个计算出来的类存进V列表里并返回*/
//                                        } 
//                                    }
                                } else {
                                    v.add(new Recurrence(p, b, c, w, 0));/*将每个计算出来的类存进V列表里并返回*/
                                }
                            }
                        }
                    }
                }
//                System.out.println(v.size());
                f.add(new Subentries(a1, v));
                f.add(new Subentries(a2, v));
//                v.clear();
            }
//            System.out.println("In X done");
//            for (int i = 0; i < in.size(); i++) {/*v in X2*/
//                ArrayList a1 = in.get(i).s;
//                int a[] = new int[2];
//                a[0] = vert;
//                a[1] = 2;
//                a1.add(a);
//                ArrayList<Recurrence> v = new ArrayList();
//                for (int p = 0; p <= k; p++) {
//                    for (int b = 0; b <= k; b++) {
//                        for (int c = 0; c <= k; c++) {
//                            for (int w = 0; w <= 4 * k; w++) {
//                                for (int j = 0; j < in.get(i).key.size(); j++) {
//
//                                    Recurrence h = in.get(i).key.get(j);
//                                    if (h.A == p - 1 && h.B == b && h.C == c && h.W == w - Fweight) {
//                                        v.add(new Recurrence(p, b, c, w, h.N));/*将每个计算出来的类存进V列表里并返回*/
//                                    } else {
//                                        v.add(new Recurrence(p, b, c, w, 0));/*将每个计算出来的类存进V列表里并返回*/
//                                    }
//                                }
//                            }
//                        }
//                    }
//                }
//                f.add(new Subentries(a1, v));
//                v.clear();
//            }
//            System.out.println("In X2 done");
            /*int k=(int) Math.pow(3,s1.size());
      for(int i=0;i<k;i++){
      }/*写一个循环,给bx的每个element延伸出一个值(0,1,2),遍历所有可能性,并赋予R.S*/
//            String name = "bag" + t.num;
            for(int h=0;h<f.get(1).s.size();h++){
                int a0[] = (int[]) f.get(0).s.get(h);
//                System.out.println((t.entry.get(1).s.size()));
//                System.out.println(a0[0]+""+a0[1]);
            }
            t.children.get(0).entry=null;
            t.entry = new ArrayList(f);
//            Dynamicprogramming.f=new ArrayList(f);
            t.process = true;
//            for(int i=0;i<a1.size();i++){
//            int a1[] = (int[]) t.entry.get(1).s.get(i);
//              System.out.println((t.entry.get(0).key.size()));
//            System.out.println(a1[0]+""+a1[1]);}
//            System.out.println();
//            t.children.get(0).entry.clear();
            Dynamicprogramming.Waitinglist.add(t.parent);
//            System.out.println("Add vertex bag is handled" + t.vert + "child" + y.get(0).vert);
        } else if (!y.get(0).process) {
            Dynamicprogramming.Waitinglist.add(y.get(0));
//            Dynamicprogramming.Waitinglist.add(t);
            return;
        }
    }
}
