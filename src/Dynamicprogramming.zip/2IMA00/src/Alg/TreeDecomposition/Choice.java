package Alg.TreeDecomposition;

import org.jgrapht.graph.Multigraph;

public abstract class Choice {
    
    abstract Integer nextChoice(Multigraph g);
    
}
