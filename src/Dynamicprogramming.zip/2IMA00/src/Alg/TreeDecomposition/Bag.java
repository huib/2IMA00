package Alg.TreeDecomposition;

import java.util.ArrayList;
import Alg.Dynamicprogramming.Subentries;

public class Bag {
    
    public Integer num;
    public Bag parent;
    public ArrayList<Bag> children;
    public ArrayList<Integer> vert;
    public Edge edge;
    public Boolean process=false;
    public ArrayList<Subentries> entry;
    
    public class Edge {
        public Integer a;
        public Integer b;
        Edge(Integer a, Integer b){
            this.a = a;
            this.b = b;
        }
        boolean equals(Integer c, Integer d){
            return (a == c && b == d) || (a == d && b == c);
        }
    }
    
    Bag(){
        children = new ArrayList<>();
        vert = new ArrayList<>();
    }
    
    Bag(Bag b){
        children = new ArrayList<>();
        vert = (ArrayList<Integer>) b.vert.clone();
    }
    
    void setEdge(Integer a, Integer b){
        edge = new Edge(a,b);
    }
    
    void add(Integer s){
        if(!vert.contains(s)){
            vert.add(s);
        }
    }
    
    boolean isEmpty(){
        return vert.isEmpty();
    }
    
    public boolean isLeaf(){
        return children.isEmpty();
    }
    
    public boolean isAddOrForget(){
        return children.size() == 1 && edge == null;
    }
    
    public boolean isAdd(){
//        if(parent == null){
//            return false;
//        }
        return children.size()==1&&children.get(0).vert.size() < vert.size();
    }
    public boolean isAddedge(){
        return children.get(0).vert.size() == vert.size()&&children.size() == 1;
    }
    public boolean isForget(){
        return children.size()==1&&children.get(0).vert.size() > vert.size();
    }
    
    void removeLastVert(){
        vert.remove(vert.size()-1);
    }
    
    void insertBelow(Bag b){
        if(!isAddOrForget()){
            System.out.println("~ERROR~!");
        } else {
            b.children.add(children.get(0));
            b.parent = this;
            this.children.set(0, b);
        }
    }
     void insertAbove(Bag b){
        parent.insertBelow(b);
    }
    
    Bag findNum(Integer n){
//        System.out.print("Looking for " + n);
        if(n == num){
//            System.out.println(", is this one");
            return this;
        } else {
//            System.out.println(", I am " + num + ", so maybe in child?");
            for(Bag b: children){
                Bag c = b.findNum(n);
                if(c != null){
                    return c;
                }
            }
        }
        return null;
    }
}
